#!/usr/bin/env bash
# إنشاء مفتاح توقيع التطبيق على جهازك (Linux / macOS). يتطلب JDK 17 (الأمر keytool) وopenssl.
# الاستخدام:  ./create-keystore.sh [alias] [CN] [COUNTRY]
set -euo pipefail
ALIAS="${1:-athar}"; CN="${2:-Athar Tayyib}"; COUNTRY="${3:-SA}"
command -v keytool >/dev/null || { echo "الأمر keytool غير موجود. ثبّت JDK 17 أولاً."; exit 1; }
command -v openssl >/dev/null || { echo "openssl غير موجود."; exit 1; }
OUT="signing-output"; mkdir -p "$OUT"
[ -e "$OUT/athar-release.keystore" ] && { echo "الملف $OUT/athar-release.keystore موجود مسبقاً. لن أستبدله."; exit 1; }
PASS="$(openssl rand -base64 48 | tr -dc 'A-Za-z0-9' | cut -c1-24)"
keytool -genkeypair -v -keystore "$OUT/athar-release.keystore" -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=${CN//,/ }, OU=Mobile, O=${CN//,/ }, C=$COUNTRY"
base64 < "$OUT/athar-release.keystore" | tr -d '\n' > "$OUT/keystore.b64"
printf 'KEYSTORE_PASSWORD=%s\nKEY_ALIAS=%s\nKEY_PASSWORD=%s\n\nKEYSTORE_BASE64 = محتوى الملف keystore.b64\n' "$PASS" "$ALIAS" "$PASS" > "$OUT/signing-info.txt"
echo ""
echo "تم إنشاء الملفات في المجلد: $OUT"
echo "احفظ athar-release.keystore وsigning-info.txt في مكانين آمنين، ولا ترفعهما على GitHub."
