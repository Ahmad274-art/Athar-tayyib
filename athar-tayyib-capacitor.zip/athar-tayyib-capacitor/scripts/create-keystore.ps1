﻿# إنشاء مفتاح توقيع التطبيق على Windows (PowerShell). يتطلب JDK 17 (الأمر keytool).
# الاستخدام:  powershell -ExecutionPolicy Bypass -File create-keystore.ps1 -Alias athar -CN "Athar Tayyib" -Country SA
param([string]$Alias = "athar", [string]$CN = "Athar Tayyib", [string]$Country = "SA")
$ErrorActionPreference = "Stop"
if (-not (Get-Command keytool -ErrorAction SilentlyContinue)) { Write-Error "الأمر keytool غير موجود. ثبّت JDK 17 أولاً."; exit 1 }
$out = "signing-output"; New-Item -ItemType Directory -Force -Path $out | Out-Null
$ks = Join-Path $out "athar-release.keystore"
if (Test-Path $ks) { Write-Error "الملف $ks موجود مسبقاً. لن أستبدله."; exit 1 }
$chars = [char[]]([char]48..[char]57 + [char]65..[char]90 + [char]97..[char]122)
$pass = -join (1..24 | ForEach-Object { $chars | Get-Random })
$cn = $CN -replace ",", " "
keytool -genkeypair -v -keystore $ks -alias $Alias -keyalg RSA -keysize 2048 -validity 10000 -storepass $pass -keypass $pass -dname "CN=$cn, OU=Mobile, O=$cn, C=$Country"
[Convert]::ToBase64String([IO.File]::ReadAllBytes($ks)) | Set-Content -NoNewline (Join-Path $out "keystore.b64")
"KEYSTORE_PASSWORD=$pass`nKEY_ALIAS=$Alias`nKEY_PASSWORD=$pass`n`nKEYSTORE_BASE64 = محتوى الملف keystore.b64" | Set-Content (Join-Path $out "signing-info.txt") -Encoding UTF8
Write-Host "تم إنشاء الملفات في المجلد: $out"
Write-Host "احفظ athar-release.keystore وsigning-info.txt في مكانين آمنين، ولا ترفعهما على GitHub."
