// يضبط مشروع الأندرويد بعد "cap add android"
import fs from 'node:fs';
import path from 'node:path';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
const gradlePath = 'android/app/build.gradle';
if (!fs.existsSync(manifestPath) || !fs.existsSync(gradlePath)) {
  console.error('لم يتم العثور على مشروع الأندرويد. نفّذ أولاً: npx cap add android');
  process.exit(1);
}

// 1) الصلاحيات + السماح بخدمة النطق (Android 11+)
let xml = fs.readFileSync(manifestPath, 'utf8');
for (const p of ['android.permission.POST_NOTIFICATIONS', 'android.permission.RECEIVE_BOOT_COMPLETED', 'android.permission.VIBRATE']) {
  if (!xml.includes(p)) xml = xml.replace('</manifest>', `    <uses-permission android:name="${p}" />\n</manifest>`);
}
if (!xml.includes('TTS_SERVICE')) {
  xml = xml.replace('<application', '<queries>\n        <intent>\n            <action android:name="android.intent.action.TTS_SERVICE" />\n        </intent>\n    </queries>\n    <application');
}
fs.writeFileSync(manifestPath, xml);

// 2) رقم الإصدار: يؤخذ من package.json ويجب أن يزيد في كل تحديث
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const [maj, min, pat] = pkg.version.split('.').map(n => parseInt(n, 10) || 0);
const versionCode = maj * 10000 + min * 100 + pat;
let gradle = fs.readFileSync(gradlePath, 'utf8');
gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`).replace(/versionName\s+"[^"]*"/, `versionName "${pkg.version}"`);

// 3) التوقيع (يُفعَّل فقط إذا وُجد مفتاح التوقيع في المتغيرات البيئية)
if (process.env.KEYSTORE_PATH && !gradle.includes('signingConfigs {')) {
  gradle = gradle.replace(/android\s*\{/, `android {
    signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_PATH"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }`);
  gradle = gradle.replace(/buildTypes\s*\{\s*release\s*\{/, m => m + `
            signingConfig signingConfigs.release`);
  console.log('تم تفعيل توقيع نسخة Release.');
}
fs.writeFileSync(gradlePath, gradle);

// 4) أيقونة شريط الإشعارات
const src = 'resources/android', dst = 'android/app/src/main/res';
for (const dir of fs.readdirSync(src)) {
  const from = path.join(src, dir), to = path.join(dst, dir);
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) fs.copyFileSync(path.join(from, f), path.join(to, f));
}
console.log(`تم ضبط المشروع: الإصدار ${pkg.version} (versionCode ${versionCode}).`);
