// يضبط مشروع الأندرويد بعد "cap add android": الصلاحيات + أيقونة شريط الإشعارات
import fs from 'node:fs';
import path from 'node:path';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(manifestPath)) {
  console.error('لم يتم العثور على مشروع الأندرويد. نفّذ أولاً: npx cap add android');
  process.exit(1);
}

let xml = fs.readFileSync(manifestPath, 'utf8');
const permissions = [
  'android.permission.POST_NOTIFICATIONS',   // إشعارات أندرويد 13+
  'android.permission.RECEIVE_BOOT_COMPLETED', // استعادة الإشعارات بعد إعادة تشغيل الهاتف
  'android.permission.VIBRATE'
];
for (const p of permissions) {
  if (!xml.includes(p)) {
    xml = xml.replace('</manifest>', `    <uses-permission android:name="${p}" />\n</manifest>`);
  }
}
fs.writeFileSync(manifestPath, xml);

// أيقونة الإشعار (أبيض على شفاف) داخل مجلدات drawable
const src = 'resources/android';
const dst = 'android/app/src/main/res';
for (const dir of fs.readdirSync(src)) {
  const from = path.join(src, dir);
  const to = path.join(dst, dir);
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) fs.copyFileSync(path.join(from, f), path.join(to, f));
}
console.log('تم ضبط AndroidManifest وأيقونة الإشعارات.');
