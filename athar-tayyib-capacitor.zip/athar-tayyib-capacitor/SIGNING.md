# مفتاح التوقيع: كيف تُحدَّث النسخ دون فقد البيانات

يقبل أندرويد تحديث تطبيق مثبّت فقط إذا تحققت **ثلاثة شروط معاً**:

1. **المعرّف نفسه** (`appId` في `capacitor.config.json`، الحالي `com.athartayyib.app`). لا تغيّره بعد النشر.
2. **مفتاح التوقيع نفسه** الذي وُقّعت به النسخة المثبّتة.
3. **رقم إصدار أكبر**. يُحسب تلقائياً من `version` في `package.json` (مثلاً 1.2.0 ← 10200). ارفع الرقم قبل كل تحديث.

عندها يُثبَّت التحديث فوق القديم وتبقى بيانات التطبيق (الأسماء والصور والإعدادات). تُحذف البيانات فقط إذا حذفت التطبيق أو مسحت بياناته من إعدادات الهاتف، لذلك ينصح بنسخة احتياطية نصية من داخل التطبيق قبل أي إجراء كبير.

> تحذير: **لا تستخدم نسخة Debug للتحديث.** مفتاح Debug يُنشأ من جديد في كل تشغيل على GitHub، فيرفض الهاتف التحديث وتضطر لحذف التطبيق، فتضيع البيانات.

> **أسهل طريقة:** شغّل workflow «Generate signing keystore» على GitHub ولا تحتاج تثبيت شيء. الشرح الكامل في [KEYSTORE-KIT.md](KEYSTORE-KIT.md). الطريقة اليدوية أدناه بديلة.\n\n## 1) إنشاء المفتاح (مرة واحدة فقط)

يلزم JDK (الأمر `keytool`). نفّذ على حاسوبك:

```bash
keytool -genkeypair -v -keystore athar-release.keystore -alias athar \
  -keyalg RSA -keysize 2048 -validity 10000
```

سيسألك عن كلمة سر المفتاح وبعض البيانات (الاسم والجهة والبلد). اكتب كلمة سر قوية واحفظها.

**احتفظ بالملف `athar-release.keystore` وبكلمات السر في مكانين آمنين على الأقل** (مدير كلمات سر + نسخة على فلاش). إذا ضاع المفتاح لن تستطيع تحديث التطبيق أبداً إلا بنشره كتطبيق جديد. لا ترفعه على GitHub (الملف `.gitignore` يستثني `*.keystore`).

## 2) تحويل المفتاح إلى نص (Base64) لوضعه في GitHub

- Linux: `base64 -w0 athar-release.keystore > keystore.b64`
- macOS: `base64 -i athar-release.keystore -o keystore.b64`
- Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("athar-release.keystore")) | Set-Content keystore.b64`

## 3) إضافة الأسرار في GitHub

من المستودع: **Settings ‹ Secrets and variables ‹ Actions ‹ New repository secret**، وأنشئ أربعة أسرار:

| الاسم | القيمة |
|---|---|
| `KEYSTORE_BASE64` | محتوى الملف `keystore.b64` كاملاً |
| `KEYSTORE_PASSWORD` | كلمة سر ملف المفتاح |
| `KEY_ALIAS` | `athar` (الاسم المستعار الذي اخترته) |
| `KEY_PASSWORD` | كلمة سر المفتاح (غالباً نفسها) |

## 4) بناء نسخة موقّعة

**Actions ‹ Build signed release (APK + AAB) ‹ Run workflow**. بعد دقائق نزّل `athar-tayyib-release` من Artifacts: فيه APK موقّع للتثبيت المباشر وملف AAB لمتجر Google Play.

## 5) إصدار تحديث لاحقاً

1. عدّل `www/index.html` أو أي ملف.
2. ارفع `version` في `package.json` (مثلاً من `1.2.0` إلى `1.2.1`)، وغيّر رقم «الإصدار» في «حول التطبيق» داخل التطبيق ليطابقه.
3. ادفع التعديلات ثم شغّل **Build signed release** (أو أنشئ وسماً مثل `v1.2.1`).
4. ثبّت الـ APK الجديد فوق القديم: تبقى بياناتك.

## البناء على جهازك بدل GitHub

```bash
export KEYSTORE_PATH=/المسار/athar-release.keystore
export KEYSTORE_PASSWORD=...  KEY_ALIAS=athar  KEY_PASSWORD=...
npm install && npx cap add android && npx capacitor-assets generate --android
node scripts/prepare-android.mjs && npx cap sync android
cd android && ./gradlew assembleRelease     # الناتج: app/build/outputs/apk/release/
```
