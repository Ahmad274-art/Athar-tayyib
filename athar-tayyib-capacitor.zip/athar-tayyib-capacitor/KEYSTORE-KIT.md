# مجموعة إنشاء مفتاح توقيع «أثر طيّب»

مفتاح التوقيع هو ما يسمح لأندرويد بقبول **تحديث** التطبيق فوق النسخة المثبّتة مع بقاء البيانات. تنشئه مرة واحدة فقط وتحتفظ به إلى الأبد.

## الطريقة 1: إنشاء المفتاح على GitHub (الأسهل، بدون تثبيت أي برنامج)

1. أنشئ مستودعاً **خاصاً (Private)** وارفع إليه المشروع (أو هذه المجموعة). يجب أن يوجد الملف `.github/workflows/generate-keystore.yml` في المستودع.
2. من تبويب **Actions** اختر **Generate signing keystore** ثم **Run workflow** (يمكنك ترك القيم الافتراضية).
3. بعد دقيقة افتح التشغيل ونزّل **athar-signing-key** من قسم **Artifacts**. بداخله:
   - `athar-release.keystore`: ملف المفتاح (**لا يُستبدل ولا يضيع**)
   - `signing-info.txt`: كلمات السر والاسم المستعار
   - `keystore.b64`: المفتاح كنص لوضعه في GitHub
4. **احفظ الملفين الأولين في مكانين آمنين** (مدير كلمات سر + فلاش). بعدها احذف التشغيل من Actions (الأيقونة ⋯ ثم Delete) لتختفي النسخة من GitHub.
5. أضف الأسرار الأربعة (Settings ‹ Secrets and variables ‹ Actions ‹ New repository secret):
   `KEYSTORE_BASE64` (محتوى keystore.b64) و`KEYSTORE_PASSWORD` و`KEY_ALIAS` و`KEY_PASSWORD` (من signing-info.txt).

**اختياري: إضافة الأسرار تلقائياً.** أنشئ رمز وصول شخصياً (Personal Access Token) بصلاحية كتابة الأسرار على هذا المستودع (fine-grained: Secrets ‹ Read and write، أو classic: repo) وأضفه سراً باسم `SECRETS_ADMIN_PAT` قبل تشغيل الـ workflow، فيضيف الأسرار الأربعة بنفسه. ما زلت بحاجة إلى حفظ الملفات من Artifacts كنسخة احتياطية لأن الأسرار لا يمكن قراءتها لاحقاً.

## الطريقة 2: على جهازك

يلزم JDK 17.

- Linux / macOS:  `chmod +x create-keystore.sh && ./create-keystore.sh athar "Athar Tayyib" SA`
- Windows (PowerShell):  `powershell -ExecutionPolicy Bypass -File create-keystore.ps1 -Alias athar -CN "Athar Tayyib" -Country SA`

يظهر المجلد `signing-output` وفيه نفس الملفات الثلاثة. ثم أضف الأسرار كما في الخطوة 5.

## بعد ذلك

شغّل **Build signed release (APK + AAB)** من مشروع Capacitor، فيخرج APK موقّع بمفتاحك. كل تحديث لاحق: ارفع `version` في `package.json` وأعد البناء ثم ثبّت الـ APK فوق القديم.

## تنبيهات مهمة

- ضياع المفتاح أو كلمة سره يعني استحالة تحديث التطبيق (تضطر لنشره كتطبيق جديد وتفقد المستخدمين وبياناتهم).
- لا ترفع `athar-release.keystore` أو `signing-info.txt` إلى المستودع.
- لا تغيّر `appId` (`com.athartayyib.app`) بعد أول نشر.
